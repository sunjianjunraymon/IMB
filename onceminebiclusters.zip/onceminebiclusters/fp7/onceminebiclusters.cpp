#include "stdafx.h"
#include<iostream>;
#include<fstream>; 
#include<sstream>; 
#include<vector>; 
#include<string>; 
#include<map>; 
#include<list>; 
#include<algorithm>
using namespace std;
#define NON_EXIST -100
/*FP-Tree�ڵ�����ݽṹ*/
typedef struct FpNode
{
	unsigned int frequence; 	string itemName;
	FpNode * parent;  	vector<FpNode *>children; 	FpNode * nextfriend;
	bool operator < (FpNode const & Node) const
	{ 	return frequence < Node.frequence;	}
}node;
/*Header table�еı���*/
struct headerItem
{
	string item; 	
	//unsigned int frequence; 	
	list<node *> phead;
	bool operator <(headerItem const & other) const
	//{	return  frequence < other.frequence;	}
	{	return  atoi(item.c_str())>atoi(other.item.c_str());	}
};
/*���뽻�׼�¼�����ݱ����ʽ*/
typedef struct transaction
{ 	string tranId; 
	unsigned int ItemNum;
	list<node> Items;
}transaction;

/* ��ȡ�ļ������н��׼�¼���洢��vector<transaction>                            */
vector<transaction> readFile(string file)
{
	vector<transaction> transactions;
	ifstream fin(file);
	if (fin.fail()) 	{ 		cout << "ERROR: CAN NOT OPEN FILE!" << endl; 		exit(-1); 	}
	string rowContent;
	while (getline(fin, rowContent))
	{
		istringstream row(rowContent); 		transaction trans_temp;
		row >> trans_temp.tranId; 		row >> trans_temp.ItemNum;
		for (auto i = 0; i < trans_temp.ItemNum; i++)
		{
			node tempNode;
			tempNode.children.clear(); 	tempNode.parent = NULL;  tempNode.nextfriend = NULL; 
			row >> tempNode.itemName;
			tempNode.frequence = 1;
			trans_temp.Items.push_back(tempNode);
		}
		transactions.push_back(trans_temp);
	}
	return transactions;
}                                         

/* ����map�������transactions�е�Item���ţ����map����û�У���ֱ��delete  */
vector<vector<node>> reRankFrequentItem( vector<transaction>& transactions)
{
	vector<vector<node>> reRankResult;
	for (auto p = transactions.begin(); p != transactions.end(); p++)
	{
		vector<node>temp(p->Items.begin(), p->Items.end());
		reRankResult.push_back(temp);
	}
	return reRankResult;
}
/* ����vector<vector<node>>���б��������ɴ�С���е�HeaderTable  */
vector<headerItem> makeheaderTable(vector<vector<node>>const &Fitems)
{
	map<string, int> mapItem;
	vector<headerItem> headerTable;
	for (auto p = Fitems.cbegin(); p != Fitems.cend(); p++)
	{
		for (auto q = p->cbegin(); q != p->cend(); q++)
		{
			if (mapItem.find(q->itemName) == mapItem.end())
			{
				mapItem[q->itemName] =1;
			}
			else
			{
				mapItem[q->itemName] += 1;
			}
		}
	}
	for (auto p = mapItem.begin(); p != mapItem.end(); p++)
	{
		headerItem tempItem;
		tempItem.item = p->first;
		tempItem.phead.clear();
		headerTable.push_back(tempItem);
	}
	sort(headerTable.rbegin(), headerTable.rend());
	return headerTable;
}
/* ����Item,���Ҹýڵ��Ƿ���headerTable�У���������λ��                    */
int findPosInheaderTable(string Item, vector<headerItem>const& headerTable)
{
	int pos = NON_EXIST;
	for (int p = 0; p != headerTable.size(); p++)
	{
		if (headerTable[p].item == Item)
		{
			pos = p;
		}
	}
	return pos;
}
/* ����һ��node,�жϴ�node�Ƿ���vector<node*>��                                                                     */
int findPosInChildren(node s, vector<node*>const & children)
{
	int pos = NON_EXIST;
	for (int i = 0; i < children.size(); i++)
	{
		if (children[i]->itemName == s.itemName)
		{
			pos = i;
		}
	}
	return pos;
}
/* ����vector<vector<node>>���б�������FP-tree                                   */
node *  CreateFpTree(vector<vector<node>>const &Fitems, vector<headerItem>& headerTable)
{
	//����FP-tree��ͷ�ڵ㲢��ʼ��
	node* HeaderNode = new node;
	HeaderNode->itemName = ""; 	HeaderNode->nextfriend = NULL; 	HeaderNode->parent = NULL;
	HeaderNode->frequence = 0; 	HeaderNode->children.clear();
	//ע�⣺��FP-treeʱ����Ҫ��֤Fitems�У������ǰ��ճ��ִ����ݼ����еģ������޷�����FP-tree
	for (int i = 0; i < Fitems.size(); i++)
	{
		//ÿһϵ�еĽ��׼�¼����һ��������λ
		//���ȶ�λ�˽��׼�¼����Ԫ����FP-tree�е�λ��
		node* NodeInFp = HeaderNode;
		int j = 0;//��¼��ǰ���ȶԵ�Fitems[i](vector)�е�node�����
		while (j != Fitems[i].size())
		{   //�ڵ�ǰ��FPNode�в��Ҵ�����Ľڵ�
			int pos = findPosInChildren(Fitems[i][j], NodeInFp->children);
			if (pos != NON_EXIST)
			{	//����ҵ�������ǰ���ӵ�Ƶ�����ӣ�FPNodeָ��ú��ӣ����亢���в�����һ���ڵ�
				NodeInFp->children[pos]->frequence += Fitems[i][j].frequence;
				NodeInFp = NodeInFp->children[pos];
				j++;
			}
			else
			{	//û�ҵ�����Fitems[i][j]�Ժ��Ԫ��(����j)ȫ��new �ڵ㣬�����ӵ�headerTable��
				while (j != Fitems[i].size())
				{
					node * new_node = new node;
					*new_node = Fitems[i][j];
					//ÿ����һ���ڵ㣬������Ƿ���HeaderTable�У�����ڣ�����ָ������ָ��
					int pos = findPosInheaderTable(new_node->itemName, headerTable);
					if (pos != NON_EXIST)
					{	headerTable[pos].phead.push_back(new_node);	}
					//��ǰ�ڵ�new_node��parent��NodeInFp,�ѵ�ǰ�ڵ����FP-tree,��ʹ����Ϊ�µ�NodeInFp
					NodeInFp->children.push_back(new_node);
					new_node->parent = NodeInFp;
					NodeInFp = new_node;
					j++;
				}
				break;
			}
		}
	}
	return HeaderNode;
}

void minlowestleaves(node* leaf, vector<node*>& leaves)
{
	vector<node *>sons= leaf->children;
	int count = sons.size();
	if (count == 0)
	{
		leaves.push_back(leaf);
	}

	for (int i=0; i<count;i++)
	{
		minlowestleaves(sons[i],leaves);
	}
}

bool comparestring(vector<string>v1, vector<string>v2)
{
	bool flag = true;
	int len1 = v1.size(); 
	int len2 = v2.size();
	if (len1 != len2)
	{
		flag = false;
	}
	else
	{ 
		for (int i = 0; i != v1.size(); i++)
		{
			if (v1[i]!= v2[i])
			{
				flag=false;
			}
		}
	}
	return flag;
}
bool compareint(vector<int>v1, vector<int>v2)
{
	bool flag = true;
	int len1 = v1.size();
	int len2 = v2.size();
	if (len1 != len2)
	{
		flag = false;
	}
	else
	{
		for (int i = 0; i != v1.size(); i++)
		{
			if (v1[i] != v2[i])
			{
				flag = false;
			}
		}
	}
	return flag;
}

int bijiaobic(vector<string>v1, vector<string>v2)
{
	bool flag = true;
	int len1 = v1.size();
	int len2 = v2.size();
	if (len1 != len2)
	{
		flag = false;
	}
	else
	{
		for (int i = 1; i != v1.size(); i++)
		{
			if (v1[i] != v2[i])
			{
				flag = false;
			}
		}
	}
	if (flag == false)
	{
		return 0;
	}
	else
	{
		if (atoi(v1[1].c_str()) >= atoi(v2[1].c_str()))
		{
			return 2;
		}
		else
		{
			return 1;
		}
	}
}

vector<vector<string>>  findbiggestbic(vector<string> branches, vector<int> nodenumbers,vector<vector<string>> bics)
{
	vector<int> volume;
	vector<string> path;
	for (int i = 0; i != nodenumbers.size(); i++)
	{   
		int n = 0;
		for (int j = 0; j != nodenumbers.size(); j++)
		{
			if (nodenumbers[j]>= nodenumbers[i])
			{
				n++;
			}
		}
		if (n >= 3)
		{
			volume.push_back(n*nodenumbers[i]);
		}
	}
	auto maxPosition=max_element(volume.begin(), volume.end());
	int juli=maxPosition-volume.begin();
	path.push_back(to_string(nodenumbers[juli]));
	for (int j = 0; j != nodenumbers.size(); j++)
	{
		if (nodenumbers[j] >= nodenumbers[juli])
		{
			path.push_back(branches[j]);
		}
	}
	bics.push_back(path);
	return bics;
}

void findpathsfromlowestleaves(vector<node*>& leaves, int NT,int k, vector<vector<string>>& bics)
{
	vector<vector<string>> branches;
	vector<vector<int>> nodenumbers;
	for (int i = 0; i != leaves.size(); i++)
	{
		vector<string> names;
		vector<int> counts;
		if (leaves[i]->frequence >= NT)
		{
			counts.push_back(leaves[i]->frequence);
			names.push_back(leaves[i]->itemName);
		}
		node* lowestleaf = leaves[i];
		while (lowestleaf->parent->itemName != "")
		{
			lowestleaf = lowestleaf->parent;
			//�����2���Ըĳ�N=0.025*��������
			if (lowestleaf->frequence >= NT)
			{
				counts.push_back(lowestleaf->frequence);
				names.push_back(lowestleaf->itemName);
			}
		}
		branches.push_back(names);
		nodenumbers.push_back(counts);
		names.clear();
		counts.clear();
	}
	for (int i = 0; i != branches.size(); i++)
	{
		if (nodenumbers[i].size() < 3)
		{
			nodenumbers.erase(nodenumbers.begin() + i);
			branches.erase(branches.begin() + i);
			i--;
		}
	}

	//delete identical biclusters
	vector<int> deleteindex;
	for (int i = 0; i != branches.size()-1; i++)
	{
		for (int j =i+1; j!= branches.size(); j++)
		{
	      if (compareint(nodenumbers[i], nodenumbers[j])&&comparestring(branches[i], branches[j]))
			{
			  deleteindex.push_back(j);
			}
		}		
	}
	sort(deleteindex.begin(), deleteindex.end());
	deleteindex.erase(unique(deleteindex.begin(), deleteindex.end()), deleteindex.end());

	for (int j:deleteindex)
	{
		nodenumbers[j].clear();
		branches[j].clear();
	}

	vector<vector<string>> copybranches;
	vector<vector<int>> copynodenumbers;
	for (int i=0;i!=branches.size();i++)
	{
		if (branches[i].size()!=0)
		{
			copybranches.push_back(branches[i]);
			copynodenumbers.push_back(nodenumbers[i]);
		}
	}
	
	for (int i = 0; i != copynodenumbers.size(); i++)
	{
		bics=findbiggestbic(copybranches[i], copynodenumbers[i],bics);
	}
	
	//delete identical biclusters
	vector<int> delsamebicindex;
	for (int i = 0; i != bics.size() - 1; i++)
	{
		for (int j = i + 1; j != bics.size(); j++)
		{
			int retval = bijiaobic(bics[i], bics[j]);
			if (retval == 0)
			{

			}
			else if (retval == 1)
			{
				delsamebicindex.push_back(i);
			}
			else if (retval == 2)
			{
				delsamebicindex.push_back(j);
			}
		}
	}
	sort(delsamebicindex.begin(), delsamebicindex.end());
	delsamebicindex.erase(unique(delsamebicindex.begin(), delsamebicindex.end()), delsamebicindex.end());
	for (int j : delsamebicindex)
	{
		bics[j].clear();
	}
	vector<vector<string>> copybics;
	for (int i = 0; i != bics.size(); i++)
	{
		if (bics[i].size() != 0)
		{
			copybics.push_back(bics[i]);
		}
	}

//����ÿ������Ҫ���bic������
	ofstream outfile;//�����ļ�
	if (k==0)
	{	
		outfile.open("bics0.txt");
	}
	else if (k==1)
	{
		outfile.open("bics1.txt");
	}
	else
	{
		outfile.open("bics2.txt");
	}
	cout << "save bics:" << endl;
	for (int i= 0; i<copybics.size(); i++)
	{
	/* for (int j = copybics[i].size()-1; j>-1; j--)
		{
			outfile<< copybics[i][j]<<"\t";
		}
		outfile<<endl;*/
		for (int j = 0; j!=copybics[i].size(); j++)
		{
			if (j == 0)
			{
				outfile <<"row lengths:";
			}
			if (j == 1)
			{
				outfile << "column values:";
			}
			outfile << copybics[i][j] << "\t";
		}
		outfile << endl;
	}
	outfile.close();
}

int main(int argc, char * argv[])
{
	vector<transaction> originaltransactions = readFile(string(argv[1]));//argv[1]�������ļ���·���������ļ���ʽ���ո�Ŀ¼��transactions�ļ�
	int NO = originaltransactions.size();
	vector<vector<node>>originalrerankResult = reRankFrequentItem(originaltransactions);//�����н����һ��Ƶ����˳������
	vector<vector<node>>wholererankResult =originalrerankResult;
	vector<headerItem> headerTable = makeheaderTable(wholererankResult);//��ʼ��HeaderTable
	node * fpTreeRoot = CreateFpTree(wholererankResult, headerTable);//��ʼ��Fp-tree
	vector<node*>leaves;
	minlowestleaves(fpTreeRoot, leaves);//find leaf nodes of the nsfp-tree
	int NT =NO*0.002;
	vector<vector<string>> bics;
	findpathsfromlowestleaves(leaves,NT,0,bics);
	system("pause");
}